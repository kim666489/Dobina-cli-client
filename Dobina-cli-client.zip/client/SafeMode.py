import os, sys, json

currentPath = os.path.abspath(__file__)
currentFolderPath = os.path.dirname(currentPath)
running = True

with open(os.path.join(currentFolderPath,"config.json"),"r",encoding="utf-8") as f:
    _config = json.load(f)

def shell():
    while running:
        cmd = input("SafeMode > ").lower().split()
        try:
            if cmd[0] == "set":
                if cmd[1] in _config:
                    _config[cmd[1]] = cmd[2]
                else:
                    print("[Error] Not config target...") 
            if cmd[0] == "save":
                with open(os.path.join(currentFolderPath,"config.json"),"w",encoding="utf-8") as f:
                    json.dump(_config,f,ensure_ascii=True,indent=4,)
            if cmd[0] == "exit":
                sys.exit(0)
        except Exception as e:
            print(f"[Error] {e}")

if __name__ == "__main__":
    shell()