import os, sys, json
import requests
import threading
import subprocess
import time
import random
import shutil

currentPath = os.path.abspath(__file__)
currentFolderPath = os.path.dirname(currentPath)

with open(os.path.join(currentFolderPath,"config.json"),"r",encoding="utf-8") as f:
    _config = json.load(f)

sess = requests.Session()

def send2server_json(content, value, method="get"):
    if method == "post":
        res = sess.post(_config["url"] + content, json=value)
    else:
        res = sess.get(_config["url"] + content, json=value)
    return res.json()

def send2server_res(content, value, method="get"):
    if method == "post":
        res = sess.post(_config["url"] + content, json=value)
    else:
        res = sess.get(_config["url"] + content, json=value)
    return res

def execute_res_server(res):
    if res["action"] == "print":
        print(res["value"])

def check_connect_server():
    try:
        sess.get(f"{_config['url']}/")
        return True, None
    except Exception as e:
        return False, e


def resolve_ssh_port(node_info):
    port = node_info.get("port", 22)
    try:
        port_value = int(port)
    except (TypeError, ValueError):
        return 22

    if port_value in {80, 443}:
        return 22
    return port_value


def build_ssh_command(node_info, port=None):
    host = node_info.get("ip")
    port_value = port if port is not None else resolve_ssh_port(node_info)
    username = node_info.get("username", "")
    if node_info.get("password") and shutil.which("sshpass"):
        return [
            "sshpass", "-p", node_info["password"],
            "ssh", "-o", "StrictHostKeyChecking=accept-new",
            "-p", str(port_value), f"{username}@{host}"
        ]
    return [
        "ssh", "-o", "StrictHostKeyChecking=accept-new",
        "-p", str(port_value), f"{username}@{host}"
    ]


def connect_to_node(node_name):
    res = send2server_json("/connect", {"node": node_name}, method="post")
    if not res.get("value"):
        print(f"[Error] {res.get('error', 'Permission denied')}")
        return False

    port = resolve_ssh_port(res)
    print(f"[Connect] Connecting to {node_name} ({res.get('ip')}:{port})...")
    cmd = build_ssh_command(res, port=port)
    try:
        result = subprocess.call(cmd, stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
        if result != 0 and port in {80, 443}:
            print("[Info] Primary port did not accept SSH, retrying with default SSH port 22...")
            cmd = build_ssh_command(res, port=22)
            return subprocess.call(cmd, stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
        return result
    except KeyboardInterrupt:
        print("\n[Info] SSH session closed.")
        return 0


def show_logo_style_1():
    print(r"""
    ____        _     _             ____  _     ___ 
   |  _ \  ___ | |__ (_)_ __   __ _/ ___|| |   |_ _|
   | | | |/ _ \| '_ \| | '_ \ / _` \___ \| |    | | 
   | |_| | (_) | |_) | | | | | (_| |___) | |___ | | 
   |____/ \___/|_.__/|_|_| |_|\__,_|____/|_____|___|
    """)

def show_logo_style_2():
    print(r"""
    ██████╗  ██████╗ ██████╗ ██╗ ███╗   ██╗ █████╗ 
    ██╔══██╗██╔═══██╗██╔══██╗██║ ████╗  ██║██╔══██╗
    ██║  ██║██║   ██║██████╔╝██║ ██╔██╗ ██║███████║
    ██║  ██║██║   ██║██╔══██╗██║ ██║╚██╗██║██╔══██║
    ██████╔╝╚██████╔╝██████╔╝██║ ██║ ╚████║██║  ██║
    ╚═════╝  ╚═════╝ ╚═════╝ ╚═╝ ╚═╝  ╚═══╝╚═╝  ╚═╝
    """)

def show_logo_style_3():
    print(r"""
    *-----------------------------------------------*
    |  D O B I N A  C L I  -  Version 1.0.0         |
    *-----------------------------------------------*
    """)

def show_logo_style_4():
    print(r"""
    Dobina CLI ------------------------------------
    >  [ D ]  [ O ]  [ B ]  [ I ]  [ N ]  [ A ]
    >  C L I  Ready...
    -----------------------------------------------
    """)

def show_logo_style_5():
    print(r"""
     .---.   .-.  .---.  .-.  .---. 
    (  _  ) / _ \(  _  )(  ) (  _  )
     ) (_) ( (_) ) (_) )  ) (  ) (_) 
    (  _  )  _  (  _  )  (  ) (  _  )
    (_) (_)(_) (_)(_) (_)  (_) (_) (_)
    Dobina CLI
    """)

def is_login():
    res = send2server_json("/islogin", {})
    return res["value"]

def autoLogin():
    res = send2server_json(
        "/login",
        {"username": _config["username"], "password": _config["password"]},
        method="post"
    )
    if not res.get("value"):
        print("[Error] Auto-login failed, check username/password in config.json")
    return res.get("value", False)

class CLI:
    def __init__(self):
        self.cli_running = False
        username = _config["username"]
        self.pom = f"{username}@CLI:~ > "

    def execute_cli(self, cmd):
        parse = cmd.strip().split()
        if not parse:
            return
        if parse[0] == "checksv":
            res = send2server_json("/checksv",{})
            for i in res["value"]:
                print(f'Node| Name:{i["name"]} IP:{i["ip"]} NodeType:{i["node_type"]} Online:{i["online"]} |')
        elif parse[0] == "connect":
            if len(parse) < 2:
                print("[Usage] connect <node-name>")
                return
            connect_to_node(parse[1])
        elif parse[0] == "exit":
            sys.exit()

    def main_cli(self):
        self.cli_running = True
        if not is_login():
            print("[Error] You is not Login...")
            print("[Try] Running a SafeMode, please calling to admin or server support...")
            return
        while self.cli_running:
            stdin = input(self.pom)
            self.execute_cli(stdin)

if __name__ == "__main__":
    show_logo = random.choice([show_logo_style_1,show_logo_style_2,show_logo_style_3,show_logo_style_4,show_logo_style_5])
    show_logo()
    print("[Checking] Connect to server...")
    conn_s,err = check_connect_server()
    if conn_s:
        print("[Success] Connected to Server great.")
        res = send2server_json("/",{})
        execute_res_server(res)
        print("Login CLI running...")
        if autoLogin():
            cli = CLI()
            cli.main_cli()
    else:
        print(f"[Error] {err}")
        print("[SafeMode] Running a SafeMode, please calling to admin or server support...")