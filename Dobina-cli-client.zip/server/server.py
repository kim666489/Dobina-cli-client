import os, sys, json # import library
from flask import Flask, render_template, request, session, jsonify
import shutil
from datetime import datetime,date
from pathlib import Path
import socket
from concurrent.futures import ThreadPoolExecutor
import platform
import subprocess

def check_node_online(ip, timeout=2):
    param = "-n" if platform.system().lower() == "windows" else "-c"
    timeout_param = "-w" if platform.system().lower() == "windows" else "-W"
    cmd = ["ping", param, "1", timeout_param, str(timeout), ip]
    try:
        result = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=timeout + 1)
        return result.returncode == 0
    except Exception:
        return False
    
print(f"start up server on time {datetime.now()}")
currentPath = os.path.abspath(__file__)
currentFolderPath = os.path.dirname(currentPath)

with open(os.path.join(currentFolderPath,"config.json"),"r",encoding="utf-8") as f:
    _config = json.load(f)

def log(text, name="server"):
    # ตรวจสอบว่าเปิดใช้งาน log หรือไม่
    if not _config.get("log", {}).get("enabled", True):
        return

    log_path = os.path.join(currentFolderPath, "server.log")
    max_size_bytes = _config.get("log", {}).get("max_size_mb", 5) * 1024 * 1024

    # ตรวจสอบขนาดไฟล์ ถ้าเกินกำหนดให้ล้าง (truncate)
    if os.path.exists(log_path) and os.path.getsize(log_path) > max_size_bytes:
        with open(log_path, "w") as f:
            f.write(f"--- Log file cleared at {datetime.now()} ---\n")

    # เขียน log พร้อม timestamp
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"[{timestamp}] [{name.upper()}] {text}\n"
    
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(log_entry)

app = Flask(__name__)
app.secret_key = _config["session_passwd"]


def user_has_permission(username, node_name, userconfig=None, nodelist=None):
    if not username:
        return False

    if userconfig is None:
        config_path = os.path.join(currentFolderPath, "data", "userconfig.json")
        with open(config_path, "r", encoding="utf-8") as f:
            userconfig = json.load(f)

    if nodelist is None:
        config_path = os.path.join(currentFolderPath, "data", "nodelist_config.json")
        with open(config_path, "r", encoding="utf-8") as f:
            nodelist = json.load(f)

    user_entry = next((u for u in userconfig if u.get("username") == username), None)
    if not user_entry:
        return False

    permissions = {str(p).lower() for p in user_entry.get("permission", [])}
    if permissions & {"root", "admin", "connect", "all", "*"}:
        return True

    node_entry = nodelist.get(node_name, {}) if isinstance(nodelist, dict) else {}
    allowed_users = {str(u).lower() for u in node_entry.get("user", [])}
    if username.lower() in allowed_users:
        return True

    return False

@app.route("/")
def home():
    session["is_login"] = False
    return jsonify({"action":"print","value":"[Hello] your connect to server, SUCESS."})

@app.route("/checksv")
def check_server():
    config_path = os.path.join(currentFolderPath, "data", "nodelist_config.json")

    with open(config_path, "r", encoding="utf-8") as f:
        datasv = json.load(f)

    def build_node(item):
        name, sv = item
        online = check_node_online(sv["ip"])
        return {
            "name": name,
            "ip": sv["ip"],
            "node_type": sv["node_type"],
            "online": online
        }

    with ThreadPoolExecutor(max_workers=10) as executor:
        sv_list = list(executor.map(build_node, datasv.items()))

    return jsonify({"action": "show_sv_list", "value": sv_list})

@app.route("/islogin")
def is_login():
    return jsonify({
        "action": None,
        "value": session.get("is_login", False),
        "username": session.get("username")
    })

@app.route("/login", methods=["POST"])
def login():
    req = request.get_json(silent=True)
    if not req or "username" not in req or "password" not in req:
        return jsonify({"action": None, "value": False, "error": "missing username/password"}), 400

    log(f"Login attempt: {req['username']}")  # ไม่ log password

    config_path = os.path.join(currentFolderPath, "data", "userconfig.json")
    with open(config_path, "r", encoding="utf-8") as f:
        userconfig = json.load(f)

    for i in userconfig:
        if i["username"] == req["username"] and i["password"] == req["password"]:
            session["is_login"] = True
            session["username"] = i["username"]   # เก็บไว้ใช้ระบุตัวตนภายหลัง
            return jsonify({"action": None, "value": True})

    return jsonify({"action": None, "value": False})

@app.route("/connect", methods=["POST"])
def connect_node():
    if not session.get("is_login", False):
        return jsonify({"action": None, "value": False, "error": "not logged in"}), 401

    req = request.get_json(silent=True) or {}
    node_name = req.get("node")
    if not node_name:
        return jsonify({"action": None, "value": False, "error": "missing node"}), 400

    config_path = os.path.join(currentFolderPath, "data", "userconfig.json")
    with open(config_path, "r", encoding="utf-8") as f:
        userconfig = json.load(f)

    config_path = os.path.join(currentFolderPath, "data", "nodelist_config.json")
    with open(config_path, "r", encoding="utf-8") as f:
        nodelist = json.load(f)

    if not user_has_permission(session.get("username"), node_name, userconfig, nodelist):
        log(f"Denied SSH access for {session.get('username')} to {node_name}")
        return jsonify({"action": None, "value": False, "error": "permission denied"})

    node = nodelist.get(node_name)
    if not node:
        return jsonify({"action": None, "value": False, "error": "node not found"})

    return jsonify({
        "action": "connect",
        "value": True,
        "node": node_name,
        "ip": node.get("ip"),
        "username": node.get("username"),
        "password": node.get("password"),
        "port": node.get("port", 22),
    })

if __name__ == "__main__":
    log("Server startup...")
    app.run(host=_config["host"],port=_config["port"],debug=_config["debug"])